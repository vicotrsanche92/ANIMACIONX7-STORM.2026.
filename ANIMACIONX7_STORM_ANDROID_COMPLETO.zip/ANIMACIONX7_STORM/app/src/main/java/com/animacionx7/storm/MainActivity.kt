package com.animacionx7.storm

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        setContentView(StormMenuView())
    }
}

private class StormMenuView : View {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val options = listOf("HISTORIA", "COMBATE LIBRE", "PERSONAJES", "OPCIONES")
    private var selected = 0
    private var message = "PROTOTIPO ANDROID • MALI-G57"
    constructor(context: android.content.Context) : super(context) { isFocusable = true }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        paint.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xFF080D20.toInt(), 0xFF172B4D.toInt(), 0xFF401B32.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint); paint.shader = null
        paint.color = 0x22FFFFFF; paint.strokeWidth = 2f
        for (i in 0..10) canvas.drawLine(w * i / 10f, 0f, w * i / 10f, h, paint)
        for (i in 0..6) canvas.drawLine(0f, h * i / 6f, w, h * i / 6f, paint)
        paint.color = 0xFFFFB000.toInt(); paint.textAlign = Paint.Align.CENTER; paint.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        paint.textSize = h * 0.105f; canvas.drawText("ANIMACIONX7", w * .5f, h * .20f, paint)
        paint.color = 0xFFEAF2FF.toInt(); paint.textSize = h * .035f; canvas.drawText("STORM  •  ANDROID EDITION", w * .5f, h * .27f, paint)
        val bw = w * .43f; val bh = h * .095f; val gap = h * .025f; val left = (w - bw) / 2f; val top = h * .34f
        options.forEachIndexed { i, label ->
            val y = top + i * (bh + gap)
            paint.color = if (i == selected) 0xFFB94A27.toInt() else 0xCC101827.toInt()
            canvas.drawRoundRect(left, y, left + bw, y + bh, 14f, 14f, paint)
            paint.color = if (i == selected) 0xFFFFE7B0.toInt() else 0xFFFFFFFF.toInt()
            paint.textSize = h * .042f; canvas.drawText(label, w / 2f, y + bh * .66f, paint)
        }
        paint.color = 0xFFBFD0E8.toInt(); paint.textSize = h * .027f
        canvas.drawText(message, w / 2f, h * .91f, paint)
        paint.textSize = h * .022f; canvas.drawText("TOCA UNA OPCIÓN PARA PROBAR EL MENÚ", w / 2f, h * .96f, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val bh = height * .095f; val gap = height * .025f; val top = height * .34f
            val index = ((event.y - top) / (bh + gap)).toInt()
            if (index in options.indices && event.y >= top) {
                selected = index
                message = when (index) {
                    0 -> "MODO HISTORIA: DEMOSTRACIÓN"
                    1 -> "COMBATE LIBRE: MÓDULO EN DESARROLLO"
                    2 -> "PERSONAJES: MÓDULO EN DESARROLLO"
                    else -> "RENDIMIENTO: PERFIL LIGERO"
                }
                invalidate()
            }
            return true
        }
        return true
    }
}
