package com.animacionx7.storm

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var info: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 16, 24, 16)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(8,13,29), Color.rgb(30,20,47), Color.rgb(8,13,29)))
        }
        val title = TextView(this).apply {
            text = "ANIMACIONX7  STORM"
            textSize =  thirty
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val subtitle = TextView(this).apply {
            text = "NINJA ARENA • ANDROID EDITION"
            textSize = 14f
            setTextColor(Color.rgb(255,170,70))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        root.addView(subtitle)
        info = TextView(this).apply {
            text = "Selecciona un modo"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }
        root.addView(info)
        addMenuButton(root, "HISTORIA", "Modo Historia: próximamente")
        addMenuButton(root, "COMBATE LIBRE", "Combate libre: módulo de demostración")
        addMenuButton(root, "PERSONAJES", "Galería de personajes: próximamente")
        addMenuButton(root, "OPCIONES", "Perfil ligero activado para dispositivos con 4 GB de RAM")
        setContentView(root)
    }
    private fun addMenuButton(parent: LinearLayout, label: String, message: String) {
        val b = Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable().apply {
                setColor(Color.rgb(111, 43, 42)); cornerRadius = 18f
                setStroke(2, Color.rgb(255, 150, 65))
            }
            setOnClickListener { info.text = message }
        }
        val lp = LinearLayout.LayoutParams( minOf(resources.displayMetrics.widthPixels / 2, 520), 58).apply { topMargin = 7; bottomMargin = 7 }
        parent.addView(b, lp)
    }
    companion object { private const val thirty = 30f }
}
