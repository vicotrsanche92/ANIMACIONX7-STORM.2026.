package com.animacionx7.storm

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import android.view.MotionEvent

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        setContentView(StormMenuView())
    }

    inner class StormMenuView : View(this) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val items = listOf("HISTORIA", "COMBATE LIBRE", "PERSONAJES", "OPCIONES")
        private var selected = "Selecciona un modo"
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val h = height.toFloat()
            p.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xFF07152D.toInt(), 0xFF172D55.toInt(), 0xFF080B18.toInt()), null, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p); p.shader = null
            // energía diagonal decorativa
            p.color = 0x5536B8FF; p.strokeWidth = 5f
            for (i in 0..7) c.drawLine(w * (0.48f + i * 0.055f), 0f, w * (0.2f + i * 0.07f), h, p)
            p.color = 0xFFFFC247.toInt(); p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD); p.textSize = h * 0.105f
            c.drawText("ANIMACIONX7 STORM", w * 0.5f, h * 0.19f, p)
            p.color = 0xFFEAF4FF.toInt(); p.textSize = h * 0.035f; p.typeface = Typeface.DEFAULT_BOLD
            c.drawText("PORT ANDROID • MODO DEMOSTRACIÓN", w * 0.5f, h * 0.26f, p)
            val bw = w * 0.38f; val bh = h * 0.105f; val gap = h * 0.025f
            items.forEachIndexed { i, label ->
                val top = h * 0.34f + i * (bh + gap)
                p.color = if (selected == label) 0xFFFFA51F.toInt() else 0xDD102B50.toInt()
                c.drawRoundRect(w/2-bw/2, top, w/2+bw/2, top+bh, 18f, 18f, p)
                p.color = 0xFFFFFFFF.toInt(); p.textSize = h * 0.043f
                c.drawText(label, w/2, top + bh*0.66f, p)
            }
            p.color = 0xFFB9CBE0.toInt(); p.textSize = h * 0.03f
            c.drawText(selected, w/2, h*0.91f, p)
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_UP) {
                val bh = height * 0.105f; val gap = height * 0.025f
                items.forEachIndexed { i, label ->
                    val top = height * 0.34f + i * (bh + gap)
                    if (e.y in top..(top+bh)) { selected = label; invalidate() }
                }
                return true
            }
            return true
        }
    }
}
